var express=require('express');
var app=express();
app.set('view engine','ejs');

app.get('/',function(req,res){
    //res.send('this is homepage');
    res.sendFile(__dirname+'/index.html');
});

app.get('/contact',function(req,res){
    //res.send('this is contact page');
    res.sendFile(__dirname+'/contact.html');
});

app.get('/profile/:id',function(req,res){
     //res.send('you requested for id '+req.params.id);
     var data={age:22,job:'SE',hobbies:['eating','fishing','cooking','traveling']};
       res.render('profile',{person:req.params.id,data:data});
});

app.listen(3000);
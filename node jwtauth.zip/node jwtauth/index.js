const express = require('express');
const app = express();
const postRoute = require('./routes/post');
require('./db');
const authRoute = require('./routes/auth');
app.use(express.json());

app.use('/api/user', authRoute);
app.use('/api/post', postRoute);

app.listen(3000, () => console.log('server is running'));

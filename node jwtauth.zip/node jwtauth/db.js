const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/JWTLogin', { useNewUrlParser: true, useUnifiedTopology: true }, (err) => {
    if (!err) {
        console.log('connection established');
    }
    else {
        console.log('error in connection:' + err);
    }
});


